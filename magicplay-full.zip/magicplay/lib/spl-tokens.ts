/**
 * lib/spl-tokens.ts
 *
 * Multi-token support for MagicPlay.
 * Supports SOL, USDC, BONK, and a custom MAGIC token.
 */

import {
  PublicKey, Connection, Transaction,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js'
import {
  TOKEN_PROGRAM_ID,
  ASSOCIATED_TOKEN_PROGRAM_ID,
  getAssociatedTokenAddress,
  createTransferInstruction,
  getAccount,
  getMint,
} from '@solana/spl-token'
import { WalletContextState } from '@solana/wallet-adapter-react'
import { getConnection }       from '@/lib/solana'

// ── Supported Tokens ──────────────────────────────────────────
export interface TokenConfig {
  symbol:    string
  name:      string
  mint:      string          // Devnet mint address
  decimals:  number
  icon:      string
  color:     string
  minBet:    number          // in token units
  maxBet:    number
  usdValue?: number          // approximate USD value for display
}

export const SUPPORTED_TOKENS: TokenConfig[] = [
  {
    symbol:   'SOL',
    name:     'Solana',
    mint:     'So11111111111111111111111111111111111111112',
    decimals: 9,
    icon:     '◎',
    color:    '#9945FF',
    minBet:   0.01,
    maxBet:   100,
    usdValue: 120,
  },
  {
    symbol:   'USDC',
    name:     'USD Coin',
    mint:     '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU', // devnet USDC
    decimals: 6,
    icon:     '$',
    color:    '#2775CA',
    minBet:   1,
    maxBet:   10_000,
    usdValue: 1,
  },
  {
    symbol:   'BONK',
    name:     'Bonk',
    mint:     'DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263', // devnet BONK
    decimals: 5,
    icon:     '🐕',
    color:    '#FFA500',
    minBet:   1_000,
    maxBet:   100_000_000,
    usdValue: 0.000015,
  },
  {
    symbol:   'MAGIC',
    name:     'MagicPlay Token',
    mint:     'MAGICXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX',   // our custom token
    decimals: 6,
    icon:     '✨',
    color:    '#A855F7',
    minBet:   1,
    maxBet:   100_000,
    usdValue: 0.05,
  },
]

export function getToken(symbol: string): TokenConfig | undefined {
  return SUPPORTED_TOKENS.find(t => t.symbol === symbol)
}

// ── Token Balance ─────────────────────────────────────────────
export async function getTokenBalance(
  walletPubkey: PublicKey,
  token: TokenConfig
): Promise<number> {
  if (token.symbol === 'SOL') {
    const conn = getConnection()
    const lamports = await conn.getBalance(walletPubkey)
    return lamports / LAMPORTS_PER_SOL
  }

  const conn = getConnection()
  const mintPubkey = new PublicKey(token.mint)
  const ata = await getAssociatedTokenAddress(mintPubkey, walletPubkey)

  try {
    const acct = await getAccount(conn, ata)
    return Number(acct.amount) / Math.pow(10, token.decimals)
  } catch {
    return 0  // Account doesn't exist = zero balance
  }
}

// ── Get all token balances at once ────────────────────────────
export async function getAllTokenBalances(
  walletPubkey: PublicKey
): Promise<Record<string, number>> {
  const results = await Promise.allSettled(
    SUPPORTED_TOKENS.map(async t => ({
      symbol: t.symbol,
      balance: await getTokenBalance(walletPubkey, t),
    }))
  )

  return Object.fromEntries(
    results
      .filter((r): r is PromiseFulfilledResult<any> => r.status === 'fulfilled')
      .map(r => [r.value.symbol, r.value.balance])
  )
}

// ── Transfer SPL Token ────────────────────────────────────────
/**
 * Build an SPL token transfer instruction (for placing bets).
 * The casino program handles this via CPI from Anchor.
 */
export async function buildTokenTransferInstruction(
  wallet:       WalletContextState,
  token:        TokenConfig,
  amount:       number,
  destination:  PublicKey
) {
  if (!wallet.publicKey) throw new Error('Wallet not connected')
  if (token.symbol === 'SOL') {
    throw new Error('Use SystemProgram.transfer for SOL')
  }

  const conn       = getConnection()
  const mintPubkey = new PublicKey(token.mint)
  const rawAmount  = BigInt(Math.floor(amount * Math.pow(10, token.decimals)))

  const sourceATA = await getAssociatedTokenAddress(mintPubkey, wallet.publicKey)
  const destATA   = await getAssociatedTokenAddress(mintPubkey, destination)

  return createTransferInstruction(
    sourceATA,
    destATA,
    wallet.publicKey,
    rawAmount,
    [],
    TOKEN_PROGRAM_ID
  )
}

// ── Format token amount ───────────────────────────────────────
export function formatTokenAmount(amount: number, token: TokenConfig): string {
  if (amount < 0.01) return `<0.01 ${token.symbol}`
  if (amount >= 1_000_000) return `${(amount / 1_000_000).toFixed(2)}M ${token.symbol}`
  if (amount >= 1_000)     return `${(amount / 1_000).toFixed(1)}K ${token.symbol}`
  return `${amount.toFixed(token.decimals > 3 ? 2 : token.decimals)} ${token.symbol}`
}

// ── Convert to USD ────────────────────────────────────────────
export function toUSD(amount: number, token: TokenConfig): string {
  if (!token.usdValue) return '—'
  const usd = amount * token.usdValue
  return usd >= 0.01 ? `$${usd.toFixed(2)}` : `<$0.01`
}
