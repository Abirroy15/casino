import { create } from 'zustand'
import { devtools, subscribeWithSelector } from 'zustand/middleware'

// ── Types ────────────────────────────────────────────────────
export type GameType = 'dice' | 'slots' | 'coinflip' | 'hilo' | 'mines' | 'roulette' | 'plinko' | 'towerx'

export interface PlayResult {
  id: string
  wallet:    string
  game:      GameType
  betAmount: number
  payout:    number
  win:       boolean
  timestamp: number
  txSignature?: string
}

export interface GameSession {
  sessionId:   string
  game:        GameType
  betAmount:   number
  status:      'pending' | 'active' | 'settled' | 'error'
  result?:     'win' | 'loss'
  erTxId?:     string  // MagicBlock Ephemeral Rollup tx
  onChainTx?:  string  // Final settlement tx
}

export interface CasinoState {
  // Wallet
  connected:   boolean
  address:     string | null
  balance:     number  // in SOL

  // UI
  activeGame:  GameType | null
  isLoading:   boolean

  // Game state
  currentSession: GameSession | null
  recentPlays:    PlayResult[]
  stats: {
    totalWagered:   number
    gamesPlayed:    number
    wins:           number
    losses:         number
    netProfit:      number
  }

  // Actions
  setConnected:      (addr: string, balance: number) => void
  setDisconnected:   () => void
  setBalance:        (b: number) => void
  openGame:          (g: GameType) => void
  closeGame:         () => void
  setLoading:        (v: boolean) => void
  startSession:      (session: GameSession) => void
  settleSession:     (result: PlayResult) => void
  addPlay:           (play: PlayResult) => void
}

// ── Store ────────────────────────────────────────────────────
export const useCasinoStore = create<CasinoState>()(
  devtools(
    subscribeWithSelector((set, get) => ({
      connected:      false,
      address:        null,
      balance:        0,
      activeGame:     null,
      isLoading:      false,
      currentSession: null,
      recentPlays:    [],
      stats: {
        totalWagered: 0,
        gamesPlayed:  0,
        wins:         0,
        losses:       0,
        netProfit:    0,
      },

      setConnected: (addr, balance) =>
        set({ connected: true, address: addr, balance }),

      setDisconnected: () =>
        set({ connected: false, address: null, balance: 0, activeGame: null }),

      setBalance: (balance) => set({ balance }),

      openGame:  (g) => set({ activeGame: g }),
      closeGame: ()  => set({ activeGame: null, currentSession: null }),

      setLoading: (v) => set({ isLoading: v }),

      startSession: (session) => set({ currentSession: session }),

      settleSession: (result) => {
        const { stats } = get()
        set({
          currentSession: null,
          recentPlays: [result, ...get().recentPlays].slice(0, 50),
          stats: {
            totalWagered: stats.totalWagered + result.betAmount,
            gamesPlayed:  stats.gamesPlayed + 1,
            wins:   result.win ? stats.wins + 1 : stats.wins,
            losses: result.win ? stats.losses : stats.losses + 1,
            netProfit: stats.netProfit + (result.payout - result.betAmount),
          },
        })
      },

      addPlay: (play) =>
        set((s) => ({ recentPlays: [play, ...s.recentPlays].slice(0, 50) })),
    })),
    { name: 'MagicPlay' }
  )
)
