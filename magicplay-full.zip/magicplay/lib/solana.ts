import {
  Connection,
  PublicKey,
  Transaction,
  SystemProgram,
  LAMPORTS_PER_SOL,
  clusterApiUrl,
  Commitment,
} from '@solana/web3.js'
import { AnchorProvider, Program, BN, Idl } from '@coral-xyz/anchor'
import { WalletContextState } from '@solana/wallet-adapter-react'

// ── Config ────────────────────────────────────────────────────
export const NETWORK      = 'devnet'
export const RPC_ENDPOINT = clusterApiUrl('devnet')
export const COMMITMENT: Commitment = 'confirmed'

// Program IDs (replace after `anchor deploy`)
export const CASINO_PROGRAM_ID = new PublicKey(
  'MagcXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
)
export const HOUSE_WALLET = new PublicKey(
  'HouseXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
)

// ── Connection Singleton ──────────────────────────────────────
let _connection: Connection | null = null
export function getConnection(): Connection {
  if (!_connection) {
    _connection = new Connection(RPC_ENDPOINT, {
      commitment:              COMMITMENT,
      confirmTransactionInitialTimeout: 60_000,
    })
  }
  return _connection
}

// ── Balance ───────────────────────────────────────────────────
export async function getSolBalance(publicKey: PublicKey): Promise<number> {
  const conn = getConnection()
  const lamports = await conn.getBalance(publicKey)
  return lamports / LAMPORTS_PER_SOL
}

// ── PDA Derivation ────────────────────────────────────────────
/** Derive the escrow PDA for a specific player + game session */
export function deriveEscrowPDA(
  playerPubkey: PublicKey,
  sessionId: BN
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      Buffer.from('escrow'),
      playerPubkey.toBuffer(),
      sessionId.toArrayLike(Buffer, 'le', 8),
    ],
    CASINO_PROGRAM_ID
  )
}

/** Derive house vault PDA */
export function deriveHouseVaultPDA(): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [Buffer.from('house_vault')],
    CASINO_PROGRAM_ID
  )
}

// ── Anchor Provider ───────────────────────────────────────────
export function getAnchorProvider(wallet: WalletContextState): AnchorProvider {
  const conn = getConnection()
  return new AnchorProvider(conn, wallet as any, {
    preflightCommitment: COMMITMENT,
    commitment:          COMMITMENT,
  })
}

// ── Utility: shorten address ──────────────────────────────────
export function shortAddr(addr: string, chars = 4): string {
  return `${addr.slice(0, chars)}...${addr.slice(-chars)}`
}

// ── Utility: SOL to lamports ──────────────────────────────────
export function solToLamports(sol: number): BN {
  return new BN(Math.floor(sol * LAMPORTS_PER_SOL))
}

// ── Verify Transaction ────────────────────────────────────────
export async function confirmTransaction(
  signature: string,
  maxRetries = 30
): Promise<boolean> {
  const conn = getConnection()
  for (let i = 0; i < maxRetries; i++) {
    const status = await conn.getSignatureStatus(signature)
    if (status.value?.confirmationStatus === 'confirmed') return true
    await new Promise(r => setTimeout(r, 1000))
  }
  return false
}

// ── Sign & Send ───────────────────────────────────────────────
export async function signAndSendTransaction(
  wallet: WalletContextState,
  transaction: Transaction
): Promise<string> {
  const conn = getConnection()

  if (!wallet.publicKey || !wallet.signTransaction) {
    throw new Error('Wallet not connected')
  }

  transaction.feePayer = wallet.publicKey
  const { blockhash } = await conn.getLatestBlockhash()
  transaction.recentBlockhash = blockhash

  const signed = await wallet.signTransaction(transaction)
  const signature = await conn.sendRawTransaction(signed.serialize(), {
    skipPreflight: false,
    preflightCommitment: COMMITMENT,
  })

  await confirmTransaction(signature)
  return signature
}
